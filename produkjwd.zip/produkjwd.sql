-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 20, 2024 at 04:28 AM
-- Server version: 5.7.19
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `produkjwd`
--

-- --------------------------------------------------------

--
-- Table structure for table `peserta`
--

CREATE TABLE `peserta` (
  `idpeserta` int(11) NOT NULL,
  `namalengkap` varchar(100) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `nowa` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `program` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `peserta`
--

INSERT INTO `peserta` (`idpeserta`, `namalengkap`, `nik`, `nowa`, `email`, `program`) VALUES
(1, 'kharisma', '3404040210820002', '08179448204', 'kharisma.anoe@gmail.com', 'Data Scientist'),
(2, 'Bagus Hermanto', '340404003972392', '0819372837283', 'bagus@gmail.com', 'Desainer Grafis');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `idprogram` int(11) NOT NULL,
  `program` varchar(60) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`idprogram`, `program`, `gambar`, `deskripsi`) VALUES
(1, 'Pelatihan Web Developer', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. '),
(2, 'Data Scientist', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. '),
(3, 'Android Developer', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. '),
(4, 'Video Editor', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. '),
(5, 'Animator', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. '),
(6, 'Content Creator', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. '),
(7, 'Enterprise Resource Planning', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. '),
(8, 'Desainer Grafis', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. '),
(9, 'Teknisi Jaringan', 'bg-title-01.jpg', 'Some quick example text to build on the card title and make up the bulk of the card\'s content. ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `peserta`
--
ALTER TABLE `peserta`
  ADD PRIMARY KEY (`idpeserta`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`idprogram`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `peserta`
--
ALTER TABLE `peserta`
  MODIFY `idpeserta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `program`
--
ALTER TABLE `program`
  MODIFY `idprogram` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
